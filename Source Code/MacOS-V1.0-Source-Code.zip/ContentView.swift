// ContentView.swift
import SwiftUI

struct ContentView: View {
    @StateObject private var viewModel = BackupViewModel()
    
    var body: some View {
        NavigationView {
            // Sidebar with folder list
            ScrollView {
                VStack(alignment: .leading, spacing: 16) {
                    Text("Folders to Backup")
                        .font(.headline)
                        .padding(.horizontal)
                    
                    ForEach($viewModel.selectedFolders) { $folder in
                        FolderRow(folder: $folder)
                            .onTapGesture {
                                viewModel.toggleFolderSelection(id: folder.id)
                            }
                    }
                    
                    Button(action: viewModel.addMoreFolders) {
                        Label("Add Folder", systemImage: "plus.circle")
                            .padding()
                            .frame(maxWidth: .infinity)
                            .background(Color.blue.opacity(0.1))
                            .cornerRadius(8)
                    }
                    
                    Spacer()
                }
                .padding(.vertical)
            }
            .navigationTitle("File Machine")
            
            // Main content area
            VStack(spacing: 24) {
                Text("Backup Configuration")
                    .font(.title)
                
                VStack(alignment: .leading, spacing: 16) {
                    // Backup Location Section
                    VStack(alignment: .leading, spacing: 12) {
                        Text("Backup Location")
                            .font(.headline)
                        
                        Button(action: viewModel.chooseBackupLocation) {
                            HStack {
                                Image(systemName: "folder")
                                
                                if let location = viewModel.backupLocation {
                                    VStack(alignment: .leading) {
                                        Text(location.name)
                                            .font(.body)
                                        Text(location.path)
                                            .font(.caption2)
                                            .foregroundColor(.secondary)
                                    }
                                } else {
                                    Text("Select Backup Location...")
                                        .foregroundColor(.gray)
                                }
                            }
                            .padding()
                            .background(Color.gray.opacity(0.1))
                            .cornerRadius(8)
                        }
                        
                        if let location = viewModel.backupLocation {
                            HStack {
                                Text("Type: \(location.type.capitalized)")
                                    .font(.caption)
                                Spacer()
                                Text("Available space: \(viewModel.getAvailableSpace(for: location.path))")
                                    .font(.caption)
                                    .foregroundColor(.green)
                            }
                        }
                    }
                    
                    // Selected Folders Summary
                    VStack(alignment: .leading, spacing: 12) {
                        Text("Selected Folders")
                            .font(.headline)
                        
                        let selectedFolders = viewModel.selectedFolders.filter { $0.selected }
                        
                        if !selectedFolders.isEmpty {
                            VStack(alignment: .leading, spacing: 8) {
                                ForEach(selectedFolders) { folder in
                                    HStack {
                                        Image(systemName: "checkmark.circle.fill")
                                            .foregroundColor(.blue)
                                        Text(folder.name)
                                    }
                                }
                                
                                Spacer()
                            }
                        } else {
                            Text("No folders selected")
                                .foregroundColor(.gray)
                                .padding()
                        }
                    }
                    
                    // Backup Status
                    VStack(alignment: .leading, spacing: 12) {
                        Text("Backup Status")
                            .font(.headline)
                        
                        HStack {
                            if viewModel.isBackupRunning {
                                ProgressView(value: viewModel.backupProgress)
                                    .progressViewStyle(LinearProgressViewStyle())
                            } else {
                                Text("Status: \(viewModel.backupStatus)")
                                    .font(.subheadline)
                            }
                        }
                        
                        if let lastDate = viewModel.lastBackupDate {
                            Text("Last backup: \(lastDate.formatted(date: .abbreviated, time: .shortened))")
                                .font(.caption)
                                .foregroundColor(.secondary)
                        }
                    }
                    
                    // Backup Button
                    VStack(spacing: 16) {
                        if viewModel.isBackupRunning {
                            Button(action: viewModel.stopBackup) {
                                Label("Stop Backup", systemImage: "stop.circle")
                                    .padding()
                                    .frame(maxWidth: .infinity)
                                    .background(Color.red.opacity(0.1))
                                    .cornerRadius(8)
                            }
                        } else {
                            Button(action: viewModel.startBackup) {
                                Label("Start Backup", systemImage: "arrow.right.circle")
                                    .padding()
                                    .frame(maxWidth: .infinity)
                                    .background(viewModel.selectedFolders.contains(where: { $0.selected })
                                        ? Color.blue : Color.gray)
                                    .foregroundColor(.white)
                                    .cornerRadius(8)
                            }
                            .disabled(viewModel.selectedFolders.filter { $0.selected }.isEmpty)
                        }
                        
                        if let backupLocation = viewModel.backupLocation,
                           !viewModel.selectedFolders.contains(where: { $0.selected }) {
                            Text("Please select at least one folder to backup")
                                .font(.caption)
                                .foregroundColor(.red)
                        }
                    }
                }
                
                Spacer()
            }
            .padding(.horizontal)
        }
        .onDisappear {
            viewModel.stopBackup()
        }
    }
}

// MARK: - Components
struct FolderRow: View {
    @Binding var folder: FolderItem
    
    var body: some View {
        HStack {
            Image(systemName: folder.selected ? "checkmark.square" : "square")
                .foregroundColor(folder.selected ? .blue : .gray)
            
            VStack(alignment: .leading) {
                Text(folder.name)
                    .font(.body)
                
                // Removed file count display
            }
            
            Spacer()
        }
        .padding(.vertical, 4)
        .padding(.horizontal, 8)
    }
}

// MARK: - Preview
#Preview {
    ContentView()
}
