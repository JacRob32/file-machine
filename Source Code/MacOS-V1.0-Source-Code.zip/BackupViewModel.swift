import SwiftUI
import Combine
import AppKit

struct FolderItem: Identifiable, Equatable, Hashable {
    let id: UUID
    var name: String
    var path: String
    var selected: Bool
    
    init(id: UUID = UUID(), name: String, path: String, selected: Bool = false) {
        self.id = id
        self.name = name
        self.path = path
        self.selected = selected
    }
}

struct BackupLocation: Identifiable {
    let id: String
    var name: String
    var path: String
    var type: String // "internal", "external", "network", "cloud"
}

class BackupViewModel: ObservableObject {
    @Published var selectedFolders = [FolderItem]() // Empty array - no defaults
    
    @Published var backupLocation: BackupLocation?
    @Published var isBackupRunning = false
    @Published var backupProgress: Double = 0.0
    @Published var backupStatus: String = "Ready to backup"
    @Published var lastBackupDate: Date?
    
    // Backup tracking
    private var totalFilesToProcess = 0
    private var filesProcessed = 0
    private var timer: Timer?
    private var backupHistory: [Date] = []
    
    init() {
        // No default location - user must select one
    }
    
    func toggleFolderSelection(id: UUID) {
        guard let index = selectedFolders.firstIndex(where: { $0.id == id }) else { return }
        selectedFolders[index].selected.toggle()
    }
    
    func addMoreFolders() {
        let openPanel = NSOpenPanel()
        openPanel.canChooseFiles = true
        openPanel.canChooseDirectories = true
        openPanel.allowsMultipleSelection = true
        openPanel.message = "Select folders to backup"
        
        if openPanel.runModal() == .OK {
            for url in openPanel.urls {
                let folder = FolderItem(
                    name: url.lastPathComponent,
                    path: url.path,
                    selected: true
                )
                self.selectedFolders.append(folder)
            }
        }
    }
    
    func chooseBackupLocation() {
        let openPanel = NSOpenPanel()
        openPanel.canChooseFiles = false
        openPanel.canChooseDirectories = true
        openPanel.message = "Select backup location"
        
        if openPanel.runModal() == .OK {
            guard let url = openPanel.url else { return }
            
            // Validate the path exists
            let fileManager = FileManager.default
            if !fileManager.directoryExists(atPath: url.path) {
                // Create directory if it doesn't exist
                do {
                    try fileManager.createDirectory(atPath: url.path, withIntermediateDirectories: true)
                } catch {
                    print("Error creating directory: \(error)")
                    self.backupStatus = "Failed to create backup location"
                    return
                }
            }
            
            let path = url.standardizedFileURL.path
            
            // Determine type based on location
            var type: String = "internal"
            if path.hasPrefix("/Volumes/") {
                type = "external"
            } else if path.hasPrefix("//") || path.hasPrefix("smb://") || path.hasPrefix("afp://") {
                type = "network"
            } else if path.contains("icloud.com") || path.lowercased().contains("cloud") {
                type = "cloud"
            }
            
            self.backupLocation = BackupLocation(
                id: UUID().uuidString,
                name: url.lastPathComponent,
                path: path,
                type: type
            )
            
            self.backupStatus = "Backup location updated"
        }
    }
    
    func startBackup() {
        // Check if backup location is selected
        guard let location = backupLocation else {
            self.backupStatus = "Please select a backup location first"
            return
        }
        
        // Validate backup location exists
        guard FileManager.default.directoryExists(atPath: location.path) else {
            self.backupStatus = "Backup location not found - please choose a valid folder"
            return
        }
        
        // Check for "File Machine Backups" folder and create if needed
        let fileMachineBackupsPath = (location.path as NSString).appendingPathComponent("File Machine Backups")
        let fileManager = FileManager.default
        
        if !fileManager.directoryExists(atPath: fileMachineBackupsPath) {
            do {
                try fileManager.createDirectory(atPath: fileMachineBackupsPath, withIntermediateDirectories: true)
            } catch {
                self.backupStatus = "Failed to create File Machine Backups directory: \(error.localizedDescription)"
                return
            }
        }
        
        isBackupRunning = true
        backupProgress = 0.0
        filesProcessed = 0
        
        // Calculate total files to process (removed fileCount dependency)
        calculateTotalFiles()
        
        backupStatus = "Starting backup..."
        
        // Clean up any previous timer
        timer?.invalidate()
        
        var currentProgress: Double = 0.0
        
        // Start the timer for backup simulation
        timer = Timer.scheduledTimer(withTimeInterval: 0.1, repeats: true) { [weak self] timer in
            guard let self = self else {
                timer.invalidate()
                return
            }
            
            // Simulate backup progress
            currentProgress += 0.05
            
            if currentProgress >= 1.0 {
                self.isBackupRunning = false
                self.backupProgress = 1.0
                self.backupStatus = "Backup completed successfully"
                self.lastBackupDate = Date()
                
                // Add to backup history
                self.backupHistory.append(Date())
                
                timer.invalidate()
            } else {
                // Update progress on main thread
                DispatchQueue.main.async {
                    self.backupProgress = currentProgress
                    
                    // Update status message based on progress
                    if currentProgress < 0.1 {
                        self.backupStatus = "Initializing backup..."
                    } else if currentProgress < 0.3 {
                        self.backupStatus = "Scanning files..."
                    } else if currentProgress < 0.6 {
                        self.backupStatus = "Copying files..."
                    } else if currentProgress < 0.9 {
                        self.backupStatus = "Verifying backup..."
                    } else {
                        self.backupStatus = "Finalizing backup..."
                    }
                }
            }
        }
        
        // Perform actual file copying in background
        performBackup(to: fileMachineBackupsPath)
    }
    
    private func performBackup(to destinationPath: String) {
        let fileManager = FileManager.default
        
        // Create backup date folder inside "File Machine Backups"
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd_HH-mm-ss"
        let backupDateFolder = "Backup_\(dateFormatter.string(from: Date()))"
        let fullDestinationPath = (destinationPath as NSString).appendingPathComponent(backupDateFolder)
        
        // Create the backup date folder
        do {
            try fileManager.createDirectory(atPath: fullDestinationPath, withIntermediateDirectories: true)
        } catch {
            self.backupStatus = "Failed to create backup directory: \(error.localizedDescription)"
            return
        }
        
        // Copy selected folders
        for folder in self.selectedFolders where folder.selected {
            guard fileManager.directoryExists(atPath: folder.path) else { continue }
            
            let destinationFolder = (fullDestinationPath as NSString).appendingPathComponent(folder.name)
            
            do {
                try fileManager.copyItem(atPath: folder.path, toPath: destinationFolder)
            } catch {
                print("Error copying \(folder.name): \(error)")
                self.backupStatus = "Error copying \(folder.name): \(error.localizedDescription)"
            }
        }
        
        self.backupStatus = "Backup completed successfully"
    }
    
    func stopBackup() {
        timer?.invalidate()
        timer = nil
        isBackupRunning = false
        backupStatus = "Backup cancelled"
    }
    
    private func calculateTotalFiles() {
        totalFilesToProcess = 0
        // Removed fileCount calculation since we removed that property from FolderItem
    }
    
    func getBackupHistory(count: Int = 10) -> [Date] {
        return backupHistory.suffix(count)
    }
    
    // Calculate available disk space for a path
    func getAvailableSpace(for path: String) -> String {
        let fileManager = FileManager.default
        
        // Check if directory exists first
        guard fileManager.directoryExists(atPath: path) else {
            return "Location not found"
        }
        
        // Primary method: Use URL resource values
        let url = URL(fileURLWithPath: path)
        
        do {
            // Use volumeAvailableCapacityForImportantUsageKey
            let values = try url.resourceValues(forKeys: [.volumeAvailableCapacityForImportantUsageKey])
            
            if let availableCapacity = values.volumeAvailableCapacityForImportantUsage {
                return formatDiskSpace(capacity: availableCapacity)
            }
        } catch {
            print("URL resource values failed: \(error)")
        }
        
        // Fallback method: Use FileManager attributesOfFileSystem
        do {
            let attrs = try fileManager.attributesOfFileSystem(forPath: path)
            
            if let freeSpace = attrs[.systemFreeSize] as? Int64 {
                return formatDiskSpace(capacity: freeSpace)
            }
        } catch {
            print("File system attributes failed: \(error)")
        }
        
        // Ultimate fallback
        return "Unknown space"
    }
    
    private func formatDiskSpace(capacity: Int64) -> String {
        let bytes = Double(capacity)
        
        // Fixed: Added TB support
        if bytes >= 1_099_511_627_776 { // 1 TB = 1024^4
            return String(format: "%.1f TB free", bytes / 1_099_511_627_776)
        } else if bytes >= 1_073_741_824 { // 1 GB = 1024^3
            return String(format: "%.1f GB free", bytes / 1_073_741_824)
        } else if bytes >= 1_048_576 { // 1 MB = 1024^2
            return String(format: "%.1f MB free", bytes / 1_048_576)
        } else if bytes >= 1_024 { // 1 KB = 1024
            return String(format: "%.1f KB free", bytes / 1_024)
        } else {
            return "\(capacity) bytes free"
        }
    }
    
    deinit {
        timer?.invalidate()
    }
}

// Extension to check if directory exists
extension FileManager {
    func directoryExists(atPath path: String) -> Bool {
        var isDirectory: ObjCBool = false
        let exists = fileExists(atPath: path, isDirectory: &isDirectory)
        return exists && isDirectory.boolValue
    }
}

